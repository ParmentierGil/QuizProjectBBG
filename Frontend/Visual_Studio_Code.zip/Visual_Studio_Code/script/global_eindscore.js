//#region FUNCTIONS

//#region GET

//#region show

//#region ListenTo


//#region init
const init = function() {
  };


document.addEventListener('DOMContentLoaded', function(){
    console.info("Page loaded");
    init();
});
//#endregion
